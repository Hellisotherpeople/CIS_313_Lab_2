/* Simple node class for the Binary Search Tree   */

public class Node
{
    int  data;
    Node left;
    Node right;

    public Node(int c)
    {
        data = c;
        left = null;
        right = null;
    }

}